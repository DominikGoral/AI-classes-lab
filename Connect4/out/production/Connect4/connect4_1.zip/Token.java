public class Token {

    private char sign;

    public char getSign() {
        return  sign;
    }

    public void setSign(char sign) {
        this.sign = sign;
    }

}
